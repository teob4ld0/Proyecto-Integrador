import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import BulletBackground from '../components/BulletBackground';
import { registerUser } from '../services/api';

function validateRegisterForm({ username, email, password, confirmPassword }) {
  const cleanUsername = username.trim();
  const cleanEmail = email.trim();

  if (!/^[a-zA-Z0-9_]{3,11}$/.test(cleanUsername)) {
    return 'Username: 3-11 caracteres, solo letras, números y _';
  }

  if (!/^\S+@\S+\.\S+$/.test(cleanEmail)) {
    return 'Ingresá un email válido.';
  }

  if ((password || '').length < 6) {
    return 'La contraseña debe tener al menos 6 caracteres.';
  }

  if (password !== confirmPassword) {
    return 'Las contraseñas no coinciden.';
  }

  return '';
}

export default function Register() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ username: '', email: '', password: '', confirmPassword: '' });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    const payload = {
      username: form.username.trim(),
      email: form.email.trim(),
      password: form.password,
      confirmPassword: form.confirmPassword,
    };

    const validationError = validateRegisterForm(payload);
    if (validationError) {
      setError(validationError);
      return;
    }

    setLoading(true);

    try {
      await registerUser(payload);
      setSuccess('Account created! Check your email to verify your account.');
      setTimeout(() => navigate('/login'), 3000);
    } catch (err) {
      setError(err.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="menu-page-container">
      <BulletBackground />

      {/* Botón de volver al Home */}
      <button className="back-arrow-btn" onClick={() => navigate('/')}>
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M10 19L3 12M3 12L10 5M3 12H21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </button>

      {/* Cabecera unificada con el Home y el Login */}
      <div className="menu-header" style={{ marginBottom: '2rem' }}>
        <h1 className="menu-title">DANMAKREW</h1>
        <h2 className="menu-subtitle">NOMERCYGAMES</h2>
      </div>

      <div className="auth-card">
        <h2>Create Account</h2>

        {error && <div className="message error">{error}</div>}
        {success && <div className="message success">{success}</div>}

        <form onSubmit={handleSubmit} noValidate>
          <div className="form-group">
            <label htmlFor="username">Username</label>
            <input
              id="username"
              name="username"
              type="text"
              placeholder="3-11 characters"
              value={form.username}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              id="email"
              name="email"
              type="email"
              placeholder="player@danma.gg"
              value={form.email}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              name="password"
              type="password"
              placeholder="Min 6 characters"
              value={form.password}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="confirmPassword">Confirm Password</label>
            <input
              id="confirmPassword"
              name="confirmPassword"
              type="password"
              placeholder="Repeat your password"
              value={form.confirmPassword}
              onChange={handleChange}
              required
            />
          </div>

          <button type="submit" className="btn-login-submit" disabled={loading}>
            {loading ? 'Creating account...' : 'Create Account'}
          </button>
        </form>

        <div className="auth-link">
          Already have an account? <Link to="/login">Log in</Link>
        </div>
      </div>
    </div>
  );
}